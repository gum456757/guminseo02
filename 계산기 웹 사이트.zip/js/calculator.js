/**
 * calculator.js
 * 삼각함수(sin, cos, tan), 루트(sqrt), 거듭제곱(^, x²), 로그(log, ln), 팩토리얼(n!)
 * 고정밀 수학 연산 및 부동소수점 보정 엔진
 */

const Calculator = (() => {
  let currentInput = '0';
  let expression = '';
  let history = [];
  let isResultEvaluated = false;
  let angleMode = 'DEG'; // 'DEG' 또는 'RAD'
  let isScientificMode = false;

  // DOM 엘리먼트 참조
  let displayEl = null;
  let historyDisplayEl = null;
  let historyListEl = null;
  let historyCountEl = null;

  function init() {
    displayEl = document.getElementById('calcDisplay');
    historyDisplayEl = document.getElementById('calcHistory');
    historyListEl = document.getElementById('historyList');
    historyCountEl = document.getElementById('historyCount');

    setupKeypadEvents();
    setupSciKeypadEvents();
    setupModeToggleEvents();
    setupKeyboardEvents();
    updateDisplay();
  }

  /**
   * 모드 토글 (기본 / 공학용, DEG / RAD)
   */
  function setupModeToggleEvents() {
    const btnBasic = document.getElementById('btnModeBasic');
    const btnSci = document.getElementById('btnModeSci');
    const sciKeypad = document.getElementById('sciKeypad');
    const angleModeSwitch = document.getElementById('angleModeSwitch');
    const btnDeg = document.getElementById('btnAngleDeg');
    const btnRad = document.getElementById('btnAngleRad');

    if (btnBasic && btnSci && sciKeypad) {
      btnBasic.addEventListener('click', () => {
        btnBasic.classList.add('active');
        btnSci.classList.remove('active');
        sciKeypad.style.display = 'none';
        if (angleModeSwitch) angleModeSwitch.style.display = 'none';
        isScientificMode = false;
      });

      btnSci.addEventListener('click', () => {
        btnSci.classList.add('active');
        btnBasic.classList.remove('active');
        sciKeypad.style.display = 'grid';
        if (angleModeSwitch) angleModeSwitch.style.display = 'flex';
        isScientificMode = true;
      });
    }

    if (btnDeg && btnRad) {
      btnDeg.addEventListener('click', () => {
        btnDeg.classList.add('active');
        btnRad.classList.remove('active');
        angleMode = 'DEG';
      });

      btnRad.addEventListener('click', () => {
        btnRad.classList.add('active');
        btnDeg.classList.remove('active');
        angleMode = 'RAD';
      });
    }
  }

  /**
   * 공학용 전용 키패드 이벤트 (sin, cos, tan, sqrt, sqr, log, ln, pi, e, fact, inv, neg)
   */
  function setupSciKeypadEvents() {
    const sciKeypad = document.getElementById('sciKeypad');
    if (!sciKeypad) return;

    sciKeypad.addEventListener('click', (e) => {
      const button = e.target.closest('button');
      if (!button) return;

      if (button.dataset.func) {
        handleScientificFunction(button.dataset.func);
      } else if (button.dataset.const) {
        handleConstant(button.dataset.const);
      } else if (button.dataset.input) {
        inputRawCharacter(button.dataset.input);
      } else if (button.dataset.op) {
        inputOperator(button.dataset.op);
      }
    });
  }

  /**
   * 기본 키패드 이벤트
   */
  function setupKeypadEvents() {
    const keypad = document.getElementById('calcKeypad');
    if (!keypad) return;

    keypad.addEventListener('click', (e) => {
      const button = e.target.closest('button');
      if (!button) return;

      if (button.dataset.num !== undefined) {
        inputNumber(button.dataset.num);
      } else if (button.dataset.op !== undefined) {
        inputOperator(button.dataset.op);
      } else if (button.dataset.action) {
        const action = button.dataset.action;
        if (action === 'clear') clearAll();
        if (action === 'backspace') deleteLast();
        if (action === 'percent') inputPercent();
        if (action === 'calculate') calculateResult();
      }
    });

    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    if (clearHistoryBtn) {
      clearHistoryBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        history = [];
        renderHistory();
      });
    }
  }

  /**
   * 키보드 이벤트
   */
  function setupKeyboardEvents() {
    window.addEventListener('keydown', (e) => {
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
        return;
      }

      if ((e.key >= '0' && e.key <= '9') || e.key === '.') {
        inputNumber(e.key);
      } else if (e.key === '+') {
        inputOperator('+');
      } else if (e.key === '-') {
        inputOperator('-');
      } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
        inputOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        inputOperator('÷');
      } else if (e.key === '^') {
        inputOperator('^');
      } else if (e.key === '(' || e.key === ')') {
        inputRawCharacter(e.key);
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        calculateResult();
      } else if (e.key === 'Backspace') {
        deleteLast();
      } else if (e.key === 'Escape') {
        clearAll();
      } else if (e.key === '%') {
        inputPercent();
      }
    });
  }

  function inputNumber(num) {
    if (isResultEvaluated) {
      currentInput = (num === '.') ? '0.' : num;
      expression = '';
      isResultEvaluated = false;
    } else {
      if (currentInput === '^ ') {
        // 거듭제곱 대기 상태에서 밑수 x 입력 -> x ^ 로 전환되어 지수 입력 대기
        currentInput = `${num} ^ `;
      } else if (currentInput === '^ 2') {
        // 제곱 대기 상태에서 밑수 x 입력 -> x ^ 2 완성
        currentInput = `${num} ^ 2`;
      } else if (num === '.') {
        // 마지막 숫자 블록에 점이 이미 있는지 확인
        const lastNumMatch = currentInput.match(/[0-9.]*$/);
        if (lastNumMatch && lastNumMatch[0].includes('.')) return;
        currentInput += '.';
      } else if (num === '00') {
        if (currentInput === '0') return;
        currentInput += '00';
      } else {
        if (currentInput === '0') {
          currentInput = num;
        } else {
          currentInput += num;
        }
      }
    }
    updateDisplay();
  }

  function inputRawCharacter(char) {
    if (isResultEvaluated) {
      expression = '';
      currentInput = char;
      isResultEvaluated = false;
    } else {
      if (currentInput === '0' && char !== ')') {
        currentInput = char;
      } else {
        currentInput += char;
      }
    }
    updateDisplay();
  }

  function inputOperator(op) {
    if (isResultEvaluated) {
      expression = `${currentInput} ${op} `;
      currentInput = '0';
      isResultEvaluated = false;
    } else {
      if (expression.endsWith(' ') && currentInput === '0') {
        expression = expression.slice(0, -3) + ` ${op} `;
      } else {
        expression += `${currentInput} ${op} `;
        currentInput = '0';
      }
    }
    updateDisplay();
  }

  function handleConstant(constType) {
    const val = constType === 'pi' ? Math.PI : Math.E;
    const formatted = cleanFloat(val).toString();
    if (isResultEvaluated || currentInput === '0') {
      currentInput = formatted;
      isResultEvaluated = false;
    } else if (currentInput === '^ ') {
      currentInput = `${formatted} ^ `;
    } else if (currentInput === '^ 2') {
      currentInput = `${formatted} ^ 2`;
    } else if (currentInput.endsWith('(') || currentInput.endsWith('+') || currentInput.endsWith('-') || currentInput.endsWith('*') || currentInput.endsWith('/')) {
      currentInput += formatted;
    } else {
      currentInput = formatted;
    }
    updateDisplay();
  }

  /**
   * 공학용 함수 (sin, cos, tan, sqrt, sqr, pow, log, ln, fact, inv, neg)
   * x 입력 후 xʸ, x², √ 클릭 시 0^2가 아니라 6^2처럼 직관적으로 완성
   */
  function handleScientificFunction(funcName) {
    if (isResultEvaluated) {
      expression = '';
      isResultEvaluated = false;
    }

    if (funcName === 'pow') {
      // 거듭제곱 xʸ
      if (currentInput === '0' || currentInput === '') {
        currentInput = '^ ';
      } else if (currentInput.endsWith(' ^ ')) {
        // 이미 ^ 가 있으면 유지
      } else {
        currentInput = `${currentInput} ^ `;
      }
      updateDisplay();
      return;
    }

    if (funcName === 'sqr') {
      // 제곱 x²
      if (currentInput === '0' || currentInput === '') {
        currentInput = '^ 2';
      } else if (currentInput.endsWith(' ^ ')) {
        currentInput = `${currentInput}2`;
      } else {
        currentInput = `${currentInput} ^ 2`;
      }
      updateDisplay();
      return;
    }

    if (funcName === 'sqrt') {
      // 제곱근 √
      if (currentInput === '0' || currentInput === '') {
        currentInput = '√(';
      } else if (currentInput.endsWith('(') || currentInput.endsWith('+') || currentInput.endsWith('-') || currentInput.endsWith('*') || currentInput.endsWith('/')) {
        currentInput += '√(';
      } else {
        currentInput = `√(${currentInput})`;
      }
      updateDisplay();
      return;
    }

    const funcPrefixes = {
      sin: 'sin(',
      cos: 'cos(',
      tan: 'tan(',
      log: 'log(',
      ln: 'ln(',
      fact: 'fact(',
      inv: '1/('
    };

    if (funcPrefixes[funcName]) {
      const prefix = funcPrefixes[funcName];
      if (currentInput === '0' || currentInput === '') {
        currentInput = prefix;
      } else if (currentInput.endsWith('(') || currentInput.endsWith('+') || currentInput.endsWith('-') || currentInput.endsWith('*') || currentInput.endsWith('/')) {
        currentInput += prefix;
      } else {
        currentInput = `${prefix}${currentInput})`;
      }
    } else if (funcName === 'neg') {
      const num = parseFloat(currentInput);
      if (!isNaN(num)) {
        currentInput = (-num).toString();
      } else if (currentInput.startsWith('-')) {
        currentInput = currentInput.slice(1);
      } else {
        currentInput = '-' + currentInput;
      }
    }
    updateDisplay();
  }

  function inputPercent() {
    const val = parseFloat(currentInput);
    if (!isNaN(val)) {
      currentInput = (val / 100).toString();
      updateDisplay();
    }
  }

  function deleteLast() {
    if (isResultEvaluated) {
      clearAll();
      return;
    }
    
    // 접두사 및 특수 연산자 한 번에 지우기
    if (currentInput.endsWith(' ^ ')) {
      currentInput = currentInput.slice(0, -3);
      if (currentInput === '') currentInput = '0';
      updateDisplay();
      return;
    }

    if (currentInput.endsWith(' ^ 2')) {
      currentInput = currentInput.slice(0, -4);
      if (currentInput === '') currentInput = '0';
      updateDisplay();
      return;
    }

    const prefixes = ['sin(', 'cos(', 'tan(', '√(', 'log(', 'ln(', 'fact(', '1/('];
    for (const p of prefixes) {
      if (currentInput.endsWith(p)) {
        currentInput = currentInput.slice(0, -p.length);
        if (currentInput === '') currentInput = '0';
        updateDisplay();
        return;
      }
    }

    if (currentInput.length > 1) {
      currentInput = currentInput.slice(0, -1);
    } else {
      currentInput = '0';
    }
    updateDisplay();
  }

  function clearAll() {
    currentInput = '0';
    expression = '';
    isResultEvaluated = false;
    updateDisplay();
  }

  /**
   * 핵심: 고정밀 수식 평가 엔진
   * 괄호 자동 닫기, 삼각함수(DEG/RAD 지원), 루트, 거듭제곱, 로그 등 정확히 계산
   */
  function calculateResult() {
    if (!expression && !isResultEvaluated && !isScientificFormula(currentInput)) return;
    
    let fullExpr = expression + currentInput;

    // 괄호 자동 완성 (열린 괄호 수만큼 닫는 괄호 자동 보충)
    const openCount = (fullExpr.match(/\(/g) || []).length;
    const closeCount = (fullExpr.match(/\)/g) || []).length;
    if (openCount > closeCount) {
      fullExpr += ')'.repeat(openCount - closeCount);
    }

    try {
      const evaluatedValue = evaluateMathExpression(fullExpr, angleMode);

      if (!isFinite(evaluatedValue) || isNaN(evaluatedValue)) {
        currentInput = '계산 불가 (범위 초과)';
        isResultEvaluated = true;
      } else {
        const cleaned = cleanFloat(evaluatedValue);
        const formattedResult = cleaned.toString();
        addHistory(fullExpr, formattedResult);
        expression = fullExpr + ' =';
        currentInput = formattedResult;
        isResultEvaluated = true;
      }
    } catch (err) {
      console.error('Calculation error:', err);
      currentInput = '수식 오류';
      isResultEvaluated = true;
    }
    updateDisplay();
  }

  function isScientificFormula(str) {
    return /[sin|cos|tan|√|sqrt|log|ln|fact|sqr|\^|\(|\)]/.test(str);
  }

  /**
   * 수식 전처리 및 안전한 수학 연산 파싱
   */
  function evaluateMathExpression(exprStr, mode) {
    let expr = exprStr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/,/g, '')
      .replace(/π/g, `${Math.PI}`)
      .replace(/\be\b/g, `${Math.E}`);

    // 끝에 남아있는 ^ 처리 (예: 6 ^ -> 6 ^ 1)
    if (expr.trim().endsWith('^')) {
      expr = expr.trim() + ' 1';
    }

    // 앞에 ^ 로 시작하는 경우 (예: ^ 2 -> 0 ^ 2)
    if (expr.trim().startsWith('^')) {
      expr = '0 ' + expr.trim();
    }

    // 거듭제곱 x^y 변환: a ^ b -> Math.pow(a, b)
    // 괄호 및 단항 함수 처리
    expr = processScientificFunctions(expr, mode);

    // ^ 연산자 처리 (정규식 기반 2^3 -> Math.pow(2, 3))
    while (expr.includes('^')) {
      const powRegex = /([0-9.]+|\([0-9.+\-*/]+\))\s*\^\s*([0-9.]+|\([0-9.+\-*/]+\))/;
      const match = expr.match(powRegex);
      if (!match) break;
      const base = match[1];
      const exponent = match[2];
      expr = expr.replace(match[0], `Math.pow(${base}, ${exponent})`);
    }

    // 최종 안전 평가
    const sanitized = expr;
    const result = Function(`'use strict'; return (${sanitized})`)();
    return result;
  }

  /**
   * 삼각함수, 루트, 로그 등 함수 변환
   */
  function processScientificFunctions(expr, mode) {
    // 1. sqr(x) -> Math.pow(x, 2)
    expr = expr.replace(/sqr\(([^)]+)\)/g, 'Math.pow($1, 2)');

    // 2. √(x) 또는 sqrt(x) -> Math.sqrt(x)
    expr = expr.replace(/[√|sqrt]\(([^)]+)\)/g, 'Math.sqrt($1)');

    // 3. log(x) -> Math.log10(x)
    expr = expr.replace(/log\(([^)]+)\)/g, 'Math.log10($1)');

    // 4. ln(x) -> Math.log(x)
    expr = expr.replace(/ln\(([^)]+)\)/g, 'Math.log($1)');

    // 5. fact(n) -> 팩토리얼 계산
    expr = expr.replace(/fact\(([^)]+)\)/g, (match, p1) => {
      const n = parseInt(p1, 10);
      return factorial(n).toString();
    });

    // 6. 삼각함수: sin, cos, tan (DEG/RAD 지원 및 특수각 완벽 보정)
    expr = expr.replace(/sin\(([^)]+)\)/g, (match, p1) => {
      return `Calculator.calcSin(${p1}, '${mode}')`;
    });

    expr = expr.replace(/cos\(([^)]+)\)/g, (match, p1) => {
      return `Calculator.calcCos(${p1}, '${mode}')`;
    });

    expr = expr.replace(/tan\(([^)]+)\)/g, (match, p1) => {
      return `Calculator.calcTan(${p1}, '${mode}')`;
    });

    return expr;
  }

  function factorial(n) {
    if (n < 0) return NaN;
    if (n === 0 || n === 1) return 1;
    let res = 1;
    for (let i = 2; i <= n; i++) {
      res *= i;
      if (!isFinite(res)) break;
    }
    return res;
  }

  /**
   * 삼각함수 정밀 계산기 (특수각 오차 보정)
   */
  function calcSin(val, mode) {
    if (mode === 'DEG') {
      const deg = ((val % 360) + 360) % 360;
      if (deg === 0 || deg === 180 || deg === 360) return 0;
      if (deg === 90) return 1;
      if (deg === 270) return -1;
      if (deg === 30 || deg === 150) return 0.5;
      if (deg === 210 || deg === 330) return -0.5;
      return cleanFloat(Math.sin(deg * (Math.PI / 180)));
    }
    return cleanFloat(Math.sin(val));
  }

  function calcCos(val, mode) {
    if (mode === 'DEG') {
      const deg = ((val % 360) + 360) % 360;
      if (deg === 90 || deg === 270) return 0;
      if (deg === 0 || deg === 360) return 1;
      if (deg === 180) return -1;
      if (deg === 60 || deg === 300) return 0.5;
      if (deg === 120 || deg === 240) return -0.5;
      return cleanFloat(Math.cos(deg * (Math.PI / 180)));
    }
    return cleanFloat(Math.cos(val));
  }

  function calcTan(val, mode) {
    if (mode === 'DEG') {
      const deg = ((val % 360) + 360) % 360;
      if (deg === 0 || deg === 180 || deg === 360) return 0;
      if (deg === 45 || deg === 225) return 1;
      if (deg === 135 || deg === 315) return -1;
      if (deg === 90 || deg === 270) return Infinity;
      return cleanFloat(Math.tan(deg * (Math.PI / 180)));
    }
    return cleanFloat(Math.tan(val));
  }

  /**
   * 부동소수점 오차 정밀 정규화
   * 0.1 + 0.2 = 0.3 보정
   */
  function cleanFloat(num) {
    if (isNaN(num)) return NaN;
    if (!isFinite(num)) return num;
    // 12자리 부동소수점 스냅
    const fixed = parseFloat(num.toPrecision(12));
    if (Math.abs(fixed) < 1e-12) return 0;
    return fixed;
  }

  function addHistory(expr, result) {
    history.unshift({ expr, result, time: new Date() });
    if (history.length > 20) history.pop();
    renderHistory();
  }

  function renderHistory() {
    if (!historyListEl || !historyCountEl) return;
    historyCountEl.textContent = history.length;

    if (history.length === 0) {
      historyListEl.innerHTML = '<div class="empty-history">계산 기록이 여기에 표시됩니다.</div>';
      return;
    }

    historyListEl.innerHTML = history.map((item, index) => `
      <div class="history-item" data-index="${index}" title="클릭하여 결과값 불러오기">
        <span class="hist-exp">${item.expr} =</span>
        <span class="hist-res">${formatNumber(item.result)}</span>
      </div>
    `).join('');

    historyListEl.querySelectorAll('.history-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = el.dataset.index;
        if (history[idx]) {
          currentInput = history[idx].result;
          expression = '';
          isResultEvaluated = true;
          updateDisplay();
        }
      });
    });
  }

  function updateDisplay() {
    if (displayEl) {
      displayEl.textContent = formatDisplay(currentInput);
    }
    if (historyDisplayEl) {
      historyDisplayEl.textContent = expression || '-';
    }
  }

  function formatDisplay(val) {
    if (val === '수식 오류' || val === '계산 불가 (범위 초과)' || val === '오류') return val;
    if (isScientificFormula(val)) return val;
    if (val.includes('.')) {
      const parts = val.split('.');
      return formatNumber(parts[0]) + '.' + parts[1];
    }
    return formatNumber(val);
  }

  function formatNumber(numStr) {
    const num = parseFloat(numStr);
    if (isNaN(num)) return numStr;
    return numStr.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  return {
    init,
    getCurrentValue: () => {
      const clean = currentInput.replace(/,/g, '');
      const val = parseFloat(clean);
      return isNaN(val) ? 0 : val;
    },
    setValue: (val) => {
      currentInput = val.toString();
      expression = '';
      isResultEvaluated = true;
      updateDisplay();
    },
    calcSin,
    calcCos,
    calcTan
  };
})();
