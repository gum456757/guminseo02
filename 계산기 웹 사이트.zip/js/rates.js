/**
 * rates.js
 * 환율 데이터 관리, 4대 거래 기준 스프레드 계산 로직, 실시간 API 연동
 */

const RatesManager = (() => {
  // 기본 지원 통화 및 시중은행 평균 스프레드 비율
  // cashSpread: 현찰 수수료율 (약 1.75% ~ 1.97%)
  // wireSpread: 송금 수수료율 (약 0.98% ~ 1.00%)
  const CURRENCIES = {
    USD: {
      code: 'USD',
      name: '미국 달러',
      symbol: '$',
      flag: '🇺🇸',
      baseRate: 1382.50,
      change: 3.50,
      changeRate: 0.25,
      cashSpread: 0.0175,
      wireSpread: 0.0098,
      unit: 1,
      decimals: 2
    },
    JPY: {
      code: 'JPY',
      name: '일본 엔',
      symbol: '¥',
      flag: '🇯🇵',
      baseRate: 912.40, // 100엔 기준 원화
      change: -2.10,
      changeRate: -0.23,
      cashSpread: 0.0175,
      wireSpread: 0.0098,
      unit: 100,       // 100엔 단위
      decimals: 2
    },
    EUR: {
      code: 'EUR',
      name: '유럽 유로',
      symbol: '€',
      flag: '🇪🇺',
      baseRate: 1495.80,
      change: 4.20,
      changeRate: 0.28,
      cashSpread: 0.0197,
      wireSpread: 0.0100,
      unit: 1,
      decimals: 2
    },
    CNY: {
      code: 'CNY',
      name: '중국 위안',
      symbol: '¥',
      flag: '🇨🇳',
      baseRate: 191.20,
      change: -0.40,
      changeRate: -0.21,
      cashSpread: 0.0500, // 중국 위안 현찰 스프레드는 약 5%
      wireSpread: 0.0100,
      unit: 1,
      decimals: 2
    },
    GBP: {
      code: 'GBP',
      name: '영국 파운드',
      symbol: '£',
      flag: '🇬🇧',
      baseRate: 1772.30,
      change: 6.80,
      changeRate: 0.39,
      cashSpread: 0.0197,
      wireSpread: 0.0098,
      unit: 1,
      decimals: 2
    }
  };

  let ratesState = { ...CURRENCIES };
  let lastUpdated = new Date();
  let isLive = false;

  /**
   * 4가지 거래 모드별 환율 계산 (우대율 discount% 반영)
   * discount: 0 ~ 100
   */
  function calculateRates(currencyCode, discount = 0) {
    const item = ratesState[currencyCode] || CURRENCIES.USD;
    const base = item.baseRate;
    const discRate = Math.min(100, Math.max(0, discount)) / 100;

    // 1. 현찰 살 때 (Cash Buy)
    const cashSpreadWon = base * item.cashSpread;
    const appliedCashBuy = base + (cashSpreadWon * (1 - discRate));

    // 2. 현찰 팔 때 (Cash Sell)
    const appliedCashSell = base - (cashSpreadWon * (1 - discRate));

    // 3. 송금 보낼 때 (Wire Send)
    const wireSpreadWon = base * item.wireSpread;
    const appliedWireSend = base + (wireSpreadWon * (1 - discRate));

    // 4. 송금 받을 때 (Wire Receive)
    const appliedWireReceive = base - (wireSpreadWon * (1 - discRate));

    return {
      code: item.code,
      name: item.name,
      symbol: item.symbol,
      flag: item.flag,
      unit: item.unit,
      baseRate: base,
      change: item.change,
      changeRate: item.changeRate,
      // 0% 기준 원래 고시 환율
      rawCashBuy: base + cashSpreadWon,
      rawCashSell: base - cashSpreadWon,
      rawWireSend: base + wireSpreadWon,
      rawWireReceive: base - wireSpreadWon,
      // 우대율 적용 후 실제 적용 환율
      cashBuy: appliedCashBuy,
      cashSell: appliedCashSell,
      wireSend: appliedWireSend,
      wireReceive: appliedWireReceive,
      // 1단위/100단위당 우대 절약 금액
      savingsCashBuy: cashSpreadWon * discRate,
      savingsCashSell: cashSpreadWon * discRate,
      savingsWireSend: wireSpreadWon * discRate,
      savingsWireReceive: wireSpreadWon * discRate
    };
  }

  /**
   * 실시간 환율 API 호출 (무료 글로벌 API 활용)
   */
  async function fetchLiveRates() {
    try {
      const response = await fetch('https://open.er-api.com/v6/latest/USD');
      if (!response.ok) throw new Error('Network response not ok');
      const data = await response.json();
      
      if (data && data.rates && data.rates.KRW) {
        const usdKrw = data.rates.KRW;
        
        // USD
        ratesState.USD.baseRate = usdKrw;
        
        // JPY (100엔당 원화)
        if (data.rates.JPY) {
          ratesState.JPY.baseRate = (usdKrw / data.rates.JPY) * 100;
        }

        // EUR
        if (data.rates.EUR) {
          ratesState.EUR.baseRate = usdKrw / data.rates.EUR;
        }

        // CNY
        if (data.rates.CNY) {
          ratesState.CNY.baseRate = usdKrw / data.rates.CNY;
        }

        // GBP
        if (data.rates.GBP) {
          ratesState.GBP.baseRate = usdKrw / data.rates.GBP;
        }

        isLive = true;
        lastUpdated = new Date();
        return true;
      }
    } catch (err) {
      console.warn('Live rate API fetch failed, using realistic benchmark rates:', err);
      // Fallback: 유지
    }
    lastUpdated = new Date();
    return false;
  }

  /**
   * 과거 n일/개월 간의 가상 트렌드 데이터 생성 (차트용)
   */
  function getHistoricalTrend(currencyCode, period = '7d') {
    const item = ratesState[currencyCode] || CURRENCIES.USD;
    const base = item.baseRate;
    let days = 7;
    if (period === '1m') days = 30;
    if (period === '3m') days = 90;

    const labels = [];
    const data = [];
    const now = new Date();

    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const dateStr = `${d.getMonth() + 1}/${d.getDate()}`;
      labels.push(dateStr);

      // 현실적인 시계열 완만한 노이즈 변동 생성
      const progress = (days - i) / days;
      const wave = Math.sin(progress * Math.PI * 2.5) * (base * 0.015);
      const randomNoise = (Math.random() - 0.5) * (base * 0.005);
      const historicalVal = Number((base - (days - 1 - i) * (item.change / days) + wave + randomNoise).toFixed(2));
      data.push(historicalVal);
    }
    // 마지막 값은 현재 baseRate와 정확히 일치
    data[data.length - 1] = Number(base.toFixed(2));

    return { labels, data, currency: item };
  }

  return {
    getAllCurrencies: () => ratesState,
    getCurrencyInfo: (code) => ratesState[code] || ratesState.USD,
    calculateRates,
    fetchLiveRates,
    getHistoricalTrend,
    getLastUpdatedTime: () => lastUpdated.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    isLiveConnected: () => isLive
  };
})();
