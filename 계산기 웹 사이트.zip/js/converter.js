/**
 * converter.js
 * 환율 변환기 로직 (4대 거래 모드, 우대율, 양방향 변환, 한글 금액 표기)
 */

const Converter = (() => {
  let activeCurrency = 'USD';
  let activeMode = 'cashBuy'; // 'cashBuy', 'cashSell', 'wireSend', 'wireReceive', 'baseRate'
  let spreadDiscount = 0;     // 0 ~ 100 (%)
  let lastChangedField = 'krw'; // 'krw' 또는 'foreign'

  // DOM 엘리먼트 참조
  let krwInput = null;
  let foreignInput = null;
  let krwSpelling = null;
  let foreignSpelling = null;
  let appliedRatePill = null;
  let sumTradeType = null;
  let sumRateComparison = null;
  let sumSavings = null;
  let spreadValueBadge = null;
  let spreadSavingsText = null;

  function init() {
    krwInput = document.getElementById('krwInput');
    foreignInput = document.getElementById('foreignInput');
    krwSpelling = document.getElementById('krwSpelling');
    foreignSpelling = document.getElementById('foreignSpelling');
    appliedRatePill = document.getElementById('appliedRatePill');
    sumTradeType = document.getElementById('sumTradeType');
    sumRateComparison = document.getElementById('sumRateComparison');
    sumSavings = document.getElementById('sumSavings');
    spreadValueBadge = document.getElementById('spreadValueBadge');
    spreadSavingsText = document.getElementById('spreadSavingsText');

    setupEventListeners();
    updateUIForCurrency();
    updateConversion();
  }

  function setupEventListeners() {
    // 1. 통화 선택 칩
    const chips = document.querySelectorAll('#currencyChips .chip');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => {
          c.classList.remove('active');
          c.setAttribute('aria-selected', 'false');
        });
        chip.classList.add('active');
        chip.setAttribute('aria-selected', 'true');
        activeCurrency = chip.dataset.currency;
        updateUIForCurrency();
        updateConversion();
        // 시세 탭 차트 및 연동 통화도 동기화
        if (window.ChartManager) {
          ChartManager.switchCurrency(activeCurrency);
        }
      });
    });

    // 2. 4가지 거래 모드 카드
    const modeCards = document.querySelectorAll('#tradeModeGrid .trade-mode-card');
    modeCards.forEach(card => {
      card.addEventListener('click', () => {
        modeCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        activeMode = card.dataset.mode;
        updateConversion();
      });
    });

    // 매매기준율 토글 버튼
    const toggleBaseRateBtn = document.getElementById('toggleBaseRateBtn');
    if (toggleBaseRateBtn) {
      toggleBaseRateBtn.addEventListener('click', () => {
        modeCards.forEach(c => c.classList.remove('active'));
        activeMode = 'baseRate';
        updateConversion();
      });
    }

    // 3. 우대율 슬라이더 & 프리셋 버튼
    const spreadSlider = document.getElementById('spreadSlider');
    const presetBtns = document.querySelectorAll('.spread-preset-btns .preset-btn');

    if (spreadSlider) {
      spreadSlider.addEventListener('input', (e) => {
        setDiscount(parseInt(e.target.value, 10));
      });
    }

    presetBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const val = parseInt(btn.dataset.val, 10);
        setDiscount(val);
      });
    });

    // 4. 원화(KRW) 입력 이벤트
    krwInput.addEventListener('input', (e) => {
      const raw = e.target.value.replace(/[^0-9]/g, '');
      if (raw === '') {
        krwInput.value = '';
        foreignInput.value = '';
        krwSpelling.textContent = '0 원';
        foreignSpelling.textContent = '-';
        return;
      }
      const num = parseInt(raw, 10);
      krwInput.value = num.toLocaleString('ko-KR');
      lastChangedField = 'krw';
      updateConversion();
    });

    // 5. 외화(Foreign) 입력 이벤트
    foreignInput.addEventListener('input', (e) => {
      // 숫자 및 소수점만 허용
      let raw = e.target.value.replace(/[^0-9.]/g, '');
      const parts = raw.split('.');
      if (parts.length > 2) raw = parts[0] + '.' + parts.slice(1).join('');
      
      foreignInput.value = raw;
      lastChangedField = 'foreign';
      updateConversion();
    });

    // 6. 스왑 버튼 (입력 포커스 및 반전)
    const swapBtn = document.getElementById('swapDirectionBtn');
    if (swapBtn) {
      swapBtn.addEventListener('click', () => {
        if (lastChangedField === 'krw') {
          lastChangedField = 'foreign';
          foreignInput.focus();
        } else {
          lastChangedField = 'krw';
          krwInput.focus();
        }
        updateConversion();
      });
    }

    // 7. 빠른 금액 추가 버튼 (KRW)
    const quickBtns = document.querySelectorAll('.krw-box .quick-btn[data-add]');
    quickBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const addVal = parseInt(btn.dataset.add, 10);
        const current = parseInt(krwInput.value.replace(/,/g, '') || '0', 10);
        const next = current + addVal;
        krwInput.value = next.toLocaleString('ko-KR');
        lastChangedField = 'krw';
        updateConversion();
      });
    });

    // KRW 초기화 버튼
    const clearKrwBtn = document.getElementById('clearKrwBtn');
    if (clearKrwBtn) {
      clearKrwBtn.addEventListener('click', () => {
        krwInput.value = '';
        foreignInput.value = '';
        krwSpelling.textContent = '0 원';
        foreignSpelling.textContent = '-';
      });
    }

    // 8. 빠른 금액 추가 버튼 (외화)
    const fQuickBtns = document.querySelectorAll('.foreign-box .quick-btn[data-fadd]');
    fQuickBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const addVal = parseFloat(btn.dataset.fadd);
        const current = parseFloat(foreignInput.value.replace(/,/g, '') || '0');
        const next = current + addVal;
        foreignInput.value = Number(next.toFixed(2)).toString();
        lastChangedField = 'foreign';
        updateConversion();
      });
    });

    // 외화 초기화 버튼
    const clearForeignBtn = document.getElementById('clearForeignBtn');
    if (clearForeignBtn) {
      clearForeignBtn.addEventListener('click', () => {
        krwInput.value = '';
        foreignInput.value = '';
        krwSpelling.textContent = '0 원';
        foreignSpelling.textContent = '-';
      });
    }
  }

  function setDiscount(val) {
    spreadDiscount = val;
    const spreadSlider = document.getElementById('spreadSlider');
    if (spreadSlider) spreadSlider.value = val;
    
    if (spreadValueBadge) spreadValueBadge.textContent = `우대 ${val}%`;

    const presetBtns = document.querySelectorAll('.spread-preset-btns .preset-btn');
    presetBtns.forEach(btn => {
      if (parseInt(btn.dataset.val, 10) === val) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    updateConversion();
  }

  /**
   * 통화 변경 시 UI 레이블, 플래그, 4대 거래 모드 카드 내 가격 갱신
   */
  function updateUIForCurrency() {
    const cur = RatesManager.getCurrencyInfo(activeCurrency);
    const rates = RatesManager.calculateRates(activeCurrency, spreadDiscount);

    // 플래그 & 레이블
    document.getElementById('foreignFlag').textContent = cur.flag;
    document.getElementById('foreignCurrencyLabel').textContent = `${cur.name} (${cur.code})`;
    document.getElementById('foreignCurrencyUnit').textContent = `${cur.code} (${cur.symbol})`;

    // 외화 빠른 추가 버튼 프리셋 조정 (JPY는 단위가 1,000엔 단위가 자연스러움)
    const fQuickContainer = document.getElementById('foreignQuickAdd');
    if (fQuickContainer) {
      if (cur.code === 'JPY') {
        fQuickContainer.innerHTML = `
          <button class="quick-btn" data-fadd="1000">+1,000</button>
          <button class="quick-btn" data-fadd="5000">+5,000</button>
          <button class="quick-btn" data-fadd="10000">+10,000</button>
          <button class="quick-btn" data-fadd="50000">+50,000</button>
          <button class="quick-btn" data-fadd="100000">+100,000</button>
          <button class="quick-btn clear-btn" id="clearForeignBtn">초기화</button>
        `;
      } else {
        fQuickContainer.innerHTML = `
          <button class="quick-btn" data-fadd="10">+10</button>
          <button class="quick-btn" data-fadd="50">+50</button>
          <button class="quick-btn" data-fadd="100">+100</button>
          <button class="quick-btn" data-fadd="500">+500</button>
          <button class="quick-btn" data-fadd="1000">+1,000</button>
          <button class="quick-btn clear-btn" id="clearForeignBtn">초기화</button>
        `;
      }
      // 새 버튼에 이벤트 재바인딩
      fQuickContainer.querySelectorAll('.quick-btn[data-fadd]').forEach(btn => {
        btn.addEventListener('click', () => {
          const addVal = parseFloat(btn.dataset.fadd);
          const current = parseFloat(foreignInput.value.replace(/,/g, '') || '0');
          const next = current + addVal;
          foreignInput.value = Number(next.toFixed(2)).toString();
          lastChangedField = 'foreign';
          updateConversion();
        });
      });
      const cBtn = document.getElementById('clearForeignBtn');
      if (cBtn) {
        cBtn.addEventListener('click', () => {
          krwInput.value = '';
          foreignInput.value = '';
          krwSpelling.textContent = '0 원';
          foreignSpelling.textContent = '-';
        });
      }
    }

    // 4가지 모드 카드 가격 텍스트 업데이트
    const unitText = cur.unit === 100 ? ' (100엔당)' : '';
    document.getElementById('rateDisplay_cashBuy').textContent = `${rates.cashBuy.toFixed(2)} 원${unitText}`;
    document.getElementById('rateDisplay_cashSell').textContent = `${rates.cashSell.toFixed(2)} 원${unitText}`;
    document.getElementById('rateDisplay_wireSend').textContent = `${rates.wireSend.toFixed(2)} 원${unitText}`;
    document.getElementById('rateDisplay_wireReceive').textContent = `${rates.wireReceive.toFixed(2)} 원${unitText}`;

    // 매매기준율 바
    document.getElementById('baseRateText').textContent = `${rates.baseRate.toFixed(2)} 원${unitText}`;
    const changeEl = document.getElementById('rateChangeText');
    const sign = rates.change > 0 ? '▲' : rates.change < 0 ? '▼' : '-';
    changeEl.textContent = `${sign} ${Math.abs(rates.change).toFixed(2)} (${rates.changeRate > 0 ? '+' : ''}${rates.changeRate}%)`;
    changeEl.className = rates.change > 0 ? 'change-up' : rates.change < 0 ? 'change-down' : 'change-neutral';
  }

  /**
   * 핵심 양방향 환율 변환 계산
   */
  function updateConversion() {
    const cur = RatesManager.getCurrencyInfo(activeCurrency);
    const rates = RatesManager.calculateRates(activeCurrency, spreadDiscount);

    // 현재 선택된 모드의 실제 적용 환율 결정
    let appliedRate = rates.cashBuy;
    let modeName = '현찰 살 때';
    let baseComparisonRate = rates.rawCashBuy;
    let unitSavings = rates.savingsCashBuy;

    if (activeMode === 'cashSell') {
      appliedRate = rates.cashSell;
      modeName = '현찰 팔 때';
      baseComparisonRate = rates.rawCashSell;
      unitSavings = rates.savingsCashSell;
    } else if (activeMode === 'wireSend') {
      appliedRate = rates.wireSend;
      modeName = '송금 보낼 때';
      baseComparisonRate = rates.rawWireSend;
      unitSavings = rates.savingsWireSend;
    } else if (activeMode === 'wireReceive') {
      appliedRate = rates.wireReceive;
      modeName = '송금 받을 때';
      baseComparisonRate = rates.rawWireReceive;
      unitSavings = rates.savingsWireReceive;
    } else if (activeMode === 'baseRate') {
      appliedRate = rates.baseRate;
      modeName = '매매기준율';
      baseComparisonRate = rates.baseRate;
      unitSavings = 0;
    }

    // 100엔 단위 등 통화 unit 고려한 1외화당 실제 원화값
    const ratePerUnit = appliedRate / cur.unit;
    const baseRatePerUnit = rates.baseRate / cur.unit;
    const rawRatePerUnit = baseComparisonRate / cur.unit;

    // 상단 적용 환율 배지 갱신
    if (appliedRatePill) {
      const unitLabel = cur.unit === 100 ? '100' : '1';
      appliedRatePill.innerHTML = `적용 환율: ${unitLabel} ${cur.code} = <strong>${appliedRate.toFixed(2)} 원</strong> (${modeName})`;
    }

    let krwAmount = 0;
    let foreignAmount = 0;

    if (lastChangedField === 'krw') {
      krwAmount = parseFloat(krwInput.value.replace(/,/g, '') || '0');
      if (krwAmount > 0 && ratePerUnit > 0) {
        foreignAmount = krwAmount / ratePerUnit;
        foreignInput.value = foreignAmount.toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
      } else if (krwInput.value === '') {
        foreignInput.value = '';
      }
    } else {
      foreignAmount = parseFloat(foreignInput.value.replace(/,/g, '') || '0');
      if (foreignAmount > 0 && ratePerUnit > 0) {
        krwAmount = foreignAmount * ratePerUnit;
        krwInput.value = Math.round(krwAmount).toLocaleString('ko-KR');
      } else if (foreignInput.value === '') {
        krwInput.value = '';
      }
    }

    // 한글 금액 표기 갱신
    if (krwSpelling) {
      krwSpelling.textContent = krwAmount > 0 ? numberToKorean(Math.round(krwAmount)) + ' 원' : '0 원';
    }
    if (foreignSpelling) {
      foreignSpelling.textContent = foreignAmount > 0 
        ? `${foreignAmount.toLocaleString('en-US', { maximumFractionDigits: 2 })} ${cur.code} (${cur.name})`
        : '-';
    }

    // 우대 절약 혜택 및 요약 카드 업데이트
    const totalSavingsWon = Math.round(foreignAmount * (unitSavings / cur.unit));
    
    if (sumTradeType) {
      sumTradeType.textContent = `${modeName} (${cur.name} ${cur.unit === 100 ? '100단위' : '1단위'})`;
    }
    if (sumRateComparison) {
      sumRateComparison.textContent = `기준 ${rates.baseRate.toFixed(2)}원 ➔ 적용 ${appliedRate.toFixed(2)}원 (우대 ${spreadDiscount}%)`;
    }
    if (sumSavings) {
      if (spreadDiscount > 0 && totalSavingsWon > 0) {
        sumSavings.textContent = `약 ${totalSavingsWon.toLocaleString('ko-KR')} 원 절약! (우대율 ${spreadDiscount}%)`;
        sumSavings.className = 'val positive';
      } else {
        sumSavings.textContent = spreadDiscount > 0 ? `우대율 ${spreadDiscount}% 적용 중` : `우대율 0% (기본 고시 환율 적용)`;
        sumSavings.className = 'val';
      }
    }

    if (spreadSavingsText) {
      if (spreadDiscount > 0 && totalSavingsWon > 0) {
        spreadSavingsText.innerHTML = `🎉 우대율 <strong>${spreadDiscount}%</strong> 적용으로 일반 고시 대비 <strong>약 ${totalSavingsWon.toLocaleString('ko-KR')}원</strong>을 아꼈습니다!`;
      } else {
        spreadSavingsText.textContent = `우대율 슬라이더나 버튼(50%, 80%, 90%)을 눌러 수수료 절감 효과를 확인하세요.`;
      }
    }
  }

  /**
   * 숫자를 읽기 쉬운 한국어 금액 단위(만, 억, 조)로 변환
   * 예: 125000000 -> 1억 2,500만
   */
  function numberToKorean(number) {
    if (isNaN(number) || number === 0) return '0';
    const units = ['', '만', '억', '조', '경'];
    let result = '';
    let temp = Math.floor(number);
    let unitIdx = 0;

    while (temp > 0) {
      const part = temp % 10000;
      if (part > 0) {
        const partStr = part.toLocaleString('ko-KR');
        result = `${partStr}${units[unitIdx]} ` + result;
      }
      temp = Math.floor(temp / 10000);
      unitIdx++;
    }

    return result.trim();
  }

  return {
    init,
    setForeignCurrency: (code) => {
      activeCurrency = code;
      const chip = document.querySelector(`#currencyChips .chip[data-currency="${code}"]`);
      if (chip) chip.click();
    },
    setKrwAmount: (val) => {
      if (krwInput) {
        krwInput.value = Math.round(val).toLocaleString('ko-KR');
        lastChangedField = 'krw';
        updateConversion();
      }
    },
    setForeignAmount: (val) => {
      if (foreignInput) {
        foreignInput.value = Number(val.toFixed(2)).toString();
        lastChangedField = 'foreign';
        updateConversion();
      }
    },
    refresh: () => {
      updateUIForCurrency();
      updateConversion();
    }
  };
})();
