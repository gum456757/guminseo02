/**
 * app.js
 * 메인 오케스트레이터: 테마 토글, 계산기 연계 버튼, 환율 아코디언 토글, 실시간 갱신 루프
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Lucide 아이콘 렌더링
  if (window.lucide) {
    lucide.createIcons();
  }

  // 1. 모듈 초기화
  RatesManager.fetchLiveRates().then(() => {
    updateRateBadge();
    if (window.Converter) Converter.refresh();
    if (window.ChartManager) ChartManager.refreshAll();
  });

  Converter.init();
  Calculator.init();
  ChartManager.init();

  // 기본 환율 업데이트 시간 표시
  updateRateBadge();

  // 2. 테마 토글 (라이트/다크)
  setupThemeToggle();

  // 3. 하단 환율 아코디언 토글
  setupCurrencyAccordion();

  // 4. 일반 계산기 -> 환율 계산기 브릿지 버튼
  setupBridgeButtons();

  // 5. 수동 환율 새로고침 버튼
  setupRefreshButton();

  // 6. 주기적 환율 갱신 (10분마다)
  setInterval(async () => {
    await RatesManager.fetchLiveRates();
    updateRateBadge();
    Converter.refresh();
    ChartManager.refreshAll();
  }, 10 * 60 * 1000);
});

/**
 * 상단 환율 상태 배지 및 시간 표시
 */
function updateRateBadge() {
  const timeEl = document.getElementById('rateUpdateTime');
  const statusTextEl = document.getElementById('rateStatusText');
  if (timeEl) {
    timeEl.textContent = RatesManager.getLastUpdatedTime();
  }
  if (statusTextEl) {
    statusTextEl.textContent = RatesManager.isLiveConnected() 
      ? '실시간 글로벌 환율 연동' 
      : '시중은행 기준 환율 적용';
  }
}

/**
 * 하단 환율 아코디언 토글 핸들러
 */
function setupCurrencyAccordion() {
  const triggerBtn = document.getElementById('currencyExpandBtn');
  const section = document.getElementById('currencyAccordion');

  if (!triggerBtn || !section) return;

  triggerBtn.addEventListener('click', () => {
    const isOpen = section.classList.contains('open');
    if (isOpen) {
      section.classList.remove('open');
      triggerBtn.setAttribute('aria-expanded', 'false');
    } else {
      section.classList.add('open');
      triggerBtn.setAttribute('aria-expanded', 'true');
      if (window.ChartManager) {
        setTimeout(() => ChartManager.refreshAll(), 80);
      }
      setTimeout(() => {
        section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    }
    if (window.lucide) lucide.createIcons();
  });
}

function openCurrencyAccordion() {
  const section = document.getElementById('currencyAccordion');
  const triggerBtn = document.getElementById('currencyExpandBtn');
  if (section && !section.classList.contains('open')) {
    section.classList.add('open');
    if (triggerBtn) triggerBtn.setAttribute('aria-expanded', 'true');
    if (window.ChartManager) {
      setTimeout(() => ChartManager.refreshAll(), 60);
    }
    if (window.lucide) lucide.createIcons();
  }
}

/**
 * 테마 토글 (시스템 설정 감지 + 사용자 로컬스토리지 저장)
 */
function setupThemeToggle() {
  const toggleBtn = document.getElementById('themeToggleBtn');
  if (!toggleBtn) return;

  const savedTheme = localStorage.getItem('theme_preference');
  if (savedTheme === 'dark') {
    document.body.classList.remove('light-theme');
    document.body.classList.add('dark-theme');
  }

  toggleBtn.addEventListener('click', () => {
    const isDark = document.body.classList.contains('dark-theme');
    if (isDark) {
      document.body.classList.remove('dark-theme');
      document.body.classList.add('light-theme');
      localStorage.setItem('theme_preference', 'light');
    } else {
      document.body.classList.remove('light-theme');
      document.body.classList.add('dark-theme');
      localStorage.setItem('theme_preference', 'dark');
    }

    if (window.lucide) lucide.createIcons();
    if (window.ChartManager) ChartManager.updateTheme();
  });
}

/**
 * 일반 계산기 -> 환율 계산기 브릿지 연동
 */
function setupBridgeButtons() {
  const sendToConverterBtn = document.getElementById('sendToConverterBtn');
  const sendToForeignBtn = document.getElementById('sendToForeignBtn');

  if (sendToConverterBtn) {
    sendToConverterBtn.addEventListener('click', () => {
      const val = Calculator.getCurrentValue();
      if (val >= 0) {
        // 아코디언이 닫혀 있다면 자동으로 열기
        openCurrencyAccordion();

        Converter.setKrwAmount(val);
        
        // 부드럽게 환율 계산기 영역으로 스크롤 이동
        const target = document.getElementById('krwBox');
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          highlightConverterBox('krwBox');
        }
      }
    });
  }

  if (sendToForeignBtn) {
    sendToForeignBtn.addEventListener('click', () => {
      const val = Calculator.getCurrentValue();
      if (val >= 0) {
        openCurrencyAccordion();

        Converter.setForeignAmount(val);

        const target = document.getElementById('foreignBox');
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          highlightConverterBox('foreignBox');
        }
      }
    });
  }
}

function highlightConverterBox(boxId) {
  const box = document.getElementById(boxId);
  if (box) {
    box.style.transition = 'all 0.3s ease';
    box.style.borderColor = 'var(--primary)';
    box.style.boxShadow = '0 0 0 4px rgba(37, 99, 235, 0.3)';
    setTimeout(() => {
      box.style.borderColor = '';
      box.style.boxShadow = '';
    }, 1200);
  }
}

/**
 * 환율 수동 새로고침 버튼
 */
function setupRefreshButton() {
  const btn = document.getElementById('refreshRatesBtn');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    btn.style.transform = 'rotate(360deg)';
    btn.style.transition = 'transform 0.6s ease';
    
    await RatesManager.fetchLiveRates();
    updateRateBadge();
    Converter.refresh();
    ChartManager.refreshAll();

    setTimeout(() => {
      btn.style.transform = '';
      btn.style.transition = '';
    }, 600);
  });
}
